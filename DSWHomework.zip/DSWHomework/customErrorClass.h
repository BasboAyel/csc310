#ifndef CUSTOM_ERROR_CLASS_H
#define CUSTOM_ERROR_CLASS_H

#include <exception>
#include <string>

class MyException : public std::exception {
public:
    MyException();
    MyException(const char* err);
    MyException(const std::string& err);
    ~MyException() noexcept override;  

    virtual const char* what() const noexcept override; 

private:
    std::string errString;
};

#endif // CUSTOM_ERROR_CLASS_H
