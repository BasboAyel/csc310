#include "customErrorClass.h"

// Default constructor
MyException::MyException() {
    this->errString = "No Error Set";
}

// Constructor with C++ string
MyException::MyException(const std::string &err) {
    this->errString = err;
}

// Constructor with C-style string
MyException::MyException(const char *err) {
    this->errString = err;
}

// Destructor (default)
MyException::~MyException() noexcept = default;  // Use 'noexcept'

// Override what() function
const char* MyException::what() const noexcept {
    return errString.c_str();
}
