#ifndef BST_H
#define BST_H

#include <iostream>
#include <vector>
#include <math.h>

using namespace std;

struct Node {
    int data; 
    Node* left;
    Node* right;

    Node(int val) 
    {
        data = val;
        left = nullptr; 
        right = nullptr;
    }
};

class BST {

private:
    Node* root;

    // Helper functions
    void rotateRight(Node*& node);
    void rotateLeft(Node*& node);
    void createVine(); // phase 1
    void rebuildTree(int size); // phase 2
    void performRotations(int count); // helper for phase 2 
    void printTree(Node* root, int space);
    int countNodes(Node* node);

public:
    BST();
    ~BST();

    void insert(int val);
    // helper for the destructor
    void deleteTree(Node* node);
    void dswBalance();

    void display();
};

#endif
