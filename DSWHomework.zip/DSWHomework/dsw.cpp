#include "dsw.h"
#include "customErrorClass.h"

// ----------------------- Private -------------------------------- 

// when we have a left heavy tree
void BST::rotateRight(Node*& node) //passing the parent
{
    if (node == nullptr || node->left == nullptr) 
        return;

    Node* leftChild = node->left;   // get the node to rotate (left child of parent)
    node->left = leftChild->right; // nodes right child gets adopted as parents left child
    leftChild->right = node;       // parent becomes right child of node
    node = leftChild;              // replace parent by node
}

//right heavy
void BST::rotateLeft(Node*& node) {
    if (node == nullptr || node->right == nullptr) 
        return;

    Node* rightChild = node->right;  // get the node to rotate (right child of parent)
    node->right = rightChild->left;  // nodes left child gets adopted as parents right child 
    rightChild->left = node;         // parent becomes left child of node   
    node = rightChild;               // replace parent by node
}

// void BST::createVine() {
//     if (root == nullptr) 
//         return;

//     Node* grandparent = nullptr;
//     Node* parent = root;
//     Node* child = root->left;

//     while (parent != nullptr) 
//     {
//         if (child != nullptr) // there is left child -> rotate right
//         {
//             rotateRight(parent);
//             if (grandparent == nullptr)
//                 root = parent;
//             else
//                 grandparent->right = parent;
//             child = parent->left;
//         } else {    // no left child - just keep moving
//             grandparent = parent;
//             parent = parent->right;
//             if (parent != nullptr)
//                 child = parent->left;
//         }
//     }
// }

int BST::countNodes(Node* node) {
    if (node == nullptr)
        return 0;
    try {
        return 1 + countNodes(node->left) + countNodes(node->right);
    } catch (std::exception &e) {
        throw MyException("Error counting nodes: Stack overflow may have occurred");
    }
}

// create vine that is partially left skewed
void BST::createVine() {
    if (root == nullptr) 
        throw MyException("Cannot create vine from an empty tree");

    try {
        Node* grandparent = nullptr;
        Node* parent = root;
        Node* child = nullptr;

        while (parent != nullptr) 
        {
            child = parent->right;
            
            if (child != nullptr) {
                // Checking if right subtree is small (size <= 2)
                int subtreeSize = countNodes(child);
                
                if (subtreeSize > 2) { // rotateing if subtree size > 2
                    rotateLeft(parent);
                    if (grandparent == nullptr)
                        root = parent;
                    else
                        grandparent->left = parent;
                    child = parent->right;
                } else {
                    // Skipping rotation for small subtrees
                    grandparent = parent;
                    parent = parent->left;
                }
            } else {
                // No right child - move to the left
                grandparent = parent;
                parent = parent->left;
            }
        }
    } catch (MyException &e) {
        throw; // Rethrow the custom exception
    } catch (std::exception &e) {
        throw MyException("Error creating vine: " + std::string(e.what()));
    } catch (...) {
        throw MyException("Unknown error occurred while creating vine");
    }
}



// void BST::rebuildTree(int size) {
//     //how many left rotations
//     //initial rotation
//     // Get the largest perfect subtree
//     int highestPowerOf2 = (int)pow(2, log2(size + 1));

//     int m = (size + 1) - highestPowerOf2;  // number of Extra nodes = nnumber of initial rotations

//     // Initial rotation
//     performRotations(m);
//     // Subsequent rotations 
//     for (size = (size - m) / 2; size > 0; size /= 2)
//         performRotations(size);
// }

// phase two - own version
void BST::rebuildTree(int size) {
    if (size <= 0)
        throw MyException("Invalid tree size for rebuilding");
        
    try {
        int targetHeight = 2 * (int)log2(size);
        
        // number of nodes in a perfectly balanced tree 
        int perfectNodeCount = (1 << (targetHeight / 2 + 1)) - 1;
        
        // number of rotations needed
        int rotationsNeeded = size - perfectNodeCount;
        rotationsNeeded = max(0, rotationsNeeded); // non-negative
        
        // Initial rotations
        performRotations(rotationsNeeded);
        
        // Subsequent rotations 
        for (int remainingNodes = size - rotationsNeeded; remainingNodes > 1; remainingNodes /= 2) {
            int halfNodes = remainingNodes / 2;
            performRotations(halfNodes);
        }
    } catch (MyException &e) {
        throw; // Rethrow the custom exception
    } catch (std::exception &e) {
        throw MyException("Error rebuilding tree: " + std::string(e.what()));
    } catch (...) {
        throw MyException("Unknown error occurred while rebuilding tree");
    }
}


// Perform left rotations on every second node based on count
// void BST::performRotations(int count) {
//     Node* grandparent = nullptr;
//     Node* parent = root;
//     Node* child = root->right;

//     for (int i = 0; i < count; i++) {
//         if (child == nullptr) 
//             break;

//         rotateLeft(parent);
//         if (grandparent == nullptr)
//             root = parent;
//         else
//             grandparent->right = parent;

//         grandparent = parent;
//         parent = parent->right;
//         if (parent != nullptr)
//             child = parent->right;
//     }
// }

//Own version - performing right rotations on every second node
void BST::performRotations(int count) {
    if (count < 0)
        throw MyException("Invalid rotation count");
        
    try {
        Node* grandparent = nullptr;
        Node* parent = root;
        Node* child = nullptr;

        for (int i = 0; i < count && parent != nullptr; i++) {
            child = parent->left;
            
            if (child == nullptr) 
                break;

            rotateRight(parent);
            if (grandparent == nullptr)
                root = parent;
            else
                grandparent->left = parent;

            grandparent = parent;
            parent = parent->left;
        }
    } catch (std::exception &e) {
        throw MyException("Error performing rotations: " + std::string(e.what()));
    } catch (...) {
        throw MyException("Unknown error occurred during rotations");
    }
}

void BST::printTree(Node* root, int space) {
    const int COUNT = 10;

    if (root == nullptr) {
        return;
    }
    //increase the distance between levels
    space += COUNT;

    // Print the right child first (to appear on the top)
    printTree(root->right, space);

    // Print current node after right child
    for (int i = COUNT; i < space; i++) {
        cout << " "; // Indentation for tree depth
    }
    cout << root->data << endl;

    // Print left child
    printTree(root->left, space);
}

// ------------------- Public ---------------------------------

BST::BST() {
    root = nullptr;
}

BST::~BST() {
    try {
        deleteTree(root);
    } catch (...) {
        // Suppress exceptions in destructor
        cerr << "Error occurred during tree deletion" << endl;
    }
}


void BST::deleteTree(Node* node) {
    if (node == nullptr) 
        return;

    try {
        deleteTree(node->left);
        deleteTree(node->right);

        delete node;
    } catch (std::exception &e) {
        throw MyException("Error deleting tree: " + std::string(e.what()));
    }
}



void BST::insert(int val) {
    try {
        Node* newNode = new Node(val);
        if (root == nullptr) {
            root = newNode;
            return;
        }

        Node* curr = root;
        Node* parent = nullptr;

        while (curr != nullptr) {
            parent = curr;
            if (val < curr->data)
                curr = curr->left;
            else
                curr = curr->right;
        }

        if (val < parent->data)
            parent->left = newNode;
        else
            parent->right = newNode;
    } catch (std::bad_alloc &e) {
        throw MyException("Memory allocation failure during node insertion");
    } catch (std::exception &e) {
        throw MyException("Error inserting node: " + std::string(e.what()));
    } catch (...) {
        throw MyException("Unknown error during node insertion");
    }
}

// void BST::dswBalance() {
//    if (root == nullptr) 
//        return;

//    // Step 1: Flatten tree into vine
//    createVine();

//    // Print vine
//    cout << "After Phase 1:";
//    display();

//    // Step 2: Count the number of nodes
//    int size = 0;
//    Node* temp = root;
//    while (temp != nullptr) {
//        size++;
//        temp = temp->right;
//    }

//    // Step 3: Rebuild tree to balance it
//    rebuildTree(size);
// }


// dswBalance for left skewed vine
void BST::dswBalance() {
    if (root == nullptr) 
        return; // Empty tree is already balanced
 
    try {
        // Step 1: Create partially left-skewed vine
        createVine();
     
        // Print vine
        cout << "After Phase 1:";
        display();
     
        // Step 2: Count the number of nodes
        int size = 0;
        Node* temp = root;
        while (temp != nullptr) {
            size++;
            temp = temp->left;
        }
     
        if (size == 0)
            throw MyException("Invalid tree structure after creating vine");
            
        // Step 3: Rebuild tree to balance it
        rebuildTree(size);
    } catch (MyException &e) {
        throw; // Rethrow the custom exception
    } catch (std::exception &e) {
        throw MyException("Error during DSW balancing: " + std::string(e.what()));
    } catch (...) {
        throw MyException("Unknown error occurred during DSW balancing");
    }
}

void BST::display() {
    try {
        cout << endl;
        printTree(root, 0);
        cout << endl;
    } catch (std::exception &e) {
        throw MyException("Error displaying tree: " + std::string(e.what()));
    } catch (...) {
        throw MyException("Unknown error occurred while displaying tree");
    }
}