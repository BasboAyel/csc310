About: DSW Balancing Trees
Date: March 1, 2025
Comments: Includes three files: dsw.h, dsw.cpp, main.cpp

*** FIRST OPEN THE FOLDER WHERE THESE THREE FILES ARE LOCATED:
    In command prompt:
        cd folder-containing-the-files
        code .
*** 
To compile: make 
To run: ./a 


Task 5 Answers
o How does this implementation differ from the traditional DSW approach.
It creates a partially left-skewed vine instead of a fully right-skewed one. It also skips rotations for small right subtrees (≤2 nodes) and relaxes balancing to keep height close to 2log2(N) instead of enforcing strict AVL balance.


o What is the impact of phase 1
Converts the BST into a partially left-skewed structure, reducing unnecessary rotations and preserving small subtrees

o What is the impact of phase 2
Performs fewer rotations while ensuring a balanced tree with a height close to 2log2(N) rather than strictly minimal height.


o What tradeoff did you observe
Fewer rotations led to faster transformation and preserving some structure  led to better memory efficiency


o Can you think of other variations
Weight-based balancing using node access frequency
